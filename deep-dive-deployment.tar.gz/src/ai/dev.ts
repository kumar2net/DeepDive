import { config } from "dotenv";
config();

import "@/ai/flows/generate-project-ideas.ts";
